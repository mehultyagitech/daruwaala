function myFunction() {
    alert("Form submitted sucessfully!");
  }
  function login() {
      var a = document.getElementById("login")
      
  }