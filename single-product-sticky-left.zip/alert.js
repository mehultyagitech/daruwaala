function myFunction() {
    alert("Form submitted sucessfully!");
  }
  